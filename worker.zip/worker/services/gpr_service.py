# RiverAI/worker/services/gpt_service.py

import os
import asyncio
from openai import OpenAI
from .generation_module import _system_prompts, _sync_call

# Инициализируем клиент OpenAI
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

async def generate_raw_tasks(prompt: str) -> str:
    """
    Генерация исходных задач по промптам OnlyGPT
    """
    # Передаём тип 'tasks' в _sync_call для выбора нужного блока промптов
    return await asyncio.to_thread(_sync_call, prompt, "tasks")

async def generate_raw_solutions(tasks: str) -> str:
    """
    Генерация решений по сгенерированным задачам
    """
    # Передаём тип 'solutions' в _sync_call для выбора нужного блока промптов
    return await asyncio.to_thread(_sync_call, tasks, "solutions")

async def generate_solutions_continuation(original: str, prompt: str) -> str:
    """
    Продолжение генерации решений, если требуется досгенерить после первого прохода
    """
    full = original.strip() + "\n\n" + prompt.strip()
    return await asyncio.to_thread(_sync_call, full, "solutions")